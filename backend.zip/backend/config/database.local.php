<?php
$host = 'sql308.infinityfree.com';
$port = 3306;
$db   = 'if0_42476675_nhom3hhh';
$user = 'if0_42476675';
$pass = 'Nhom3hhh';